<?php
require_once("./getdata_file.php");

$data = "davadonvjlbwauivzs";
link_seccess_test_echo();
// link_seccess_test($data);





 ?>
