<?php
require_once './tests/config.php';
require_once './upyun.class.php';

define('USER_NAME', $config['user_name']);
define('PWD', $config['pwd']);
define('BUCKET', $config['bucket']);

define('PIC_PATH' , $config['picture_path']);