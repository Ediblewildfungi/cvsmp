<?php
$config =  array(
		'user_name' => 'kami',
		'pwd' => 'yojo-Si5s-kami',
		'bucket' => 'kamisama',
		'picture_path' => dirname(__FILE__) . '/assets/sample.jpeg'
	);
