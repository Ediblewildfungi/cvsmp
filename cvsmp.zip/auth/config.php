<?php

//数据库配置全局常量
define("DBHOST","localhost");
define("DBUSER","root");
define("DBPWD","");
define("DBNAME","cvsmp");

//设置时区
date_default_timezone_set('Asia/Shanghai');

 ?>
