<?php

//数据库配置全局常量
define("DBHOST","your_database_host");
define("DBUSER","your_database_user");
define("DBPWD","your_database_pwd");
define("DBNAME","cvsmp");

//设置时区
date_default_timezone_set('Asia/Shanghai');

 ?>
